/**
 * @brief
 * Example 01 for CMake quick tutorial
 */

#include <iostream>

using namespace std;

int main() {
    cout << "This is Example_01 for CMake quick tutorial" << endl;
    return 0;
}