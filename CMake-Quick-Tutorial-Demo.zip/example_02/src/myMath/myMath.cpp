#include "myMath.h"

/**
 * @brief Calculate the result of N!
 * 
 * @param value     the N
 * @param order     the step, default 1.0
 * @return double   the result
 */
double my_factorial(double value, double order)
{
    if (value <= 0)
    {
        return 1.0;
    }
    return value * my_factorial((value - order), order);
}