#include "myMath/myMath.h"
#include <iostream>

int main(){
    std::cout << "5! = " << my_factorial(5) << std::endl;
}